import jquery from 'jquery';
export default (window.$ = window.jQuery = jquery);