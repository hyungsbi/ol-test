import './jquery.sidr.dark.css';
import './style.css';
import './jquery-export';
import '/node_modules/sidr/dist/jquery.sidr';
import menuImg from './menu.gif';

export class MyMenu {
    static initLeftMenu() {
        $(document).ready(function () {
            $('#simple-menu').sidr({
              timing: 'ease-in-out',
              speed: 500
            });
        });
        
        $( window ).resize(function () {
            $.sidr('close', 'sidr');
        });

        this.loadImg();
    }

    static loadImg() {
        // 방법 1: dist 폴더에 이미지를 미리 가져 놓는 방법
        /*
        $('#imgContainer').append('<img src="/images/menu.gif" width="34" height="31">');
        */

        // 방법 2: 이미지 경로를 import, 단 빌드시 소스 폴더의 이미지 경로와는 다른 이름과 위치로 이미지가 생성됨
        $('#imgContainer').append('<img src="' + menuImg + '" width="34" height="31">');
    }
};