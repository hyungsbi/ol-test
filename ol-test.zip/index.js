import './jquery.sidr.dark.css';
import './style.css';
import './jquery-export';
import '/node_modules/sidr/dist/jquery.sidr';
import {MyMenu} from './my.menu';

console.log('[index.js]');

/* $(document).ready(function () {
    $('#simple-menu').sidr({
      timing: 'ease-in-out',
      speed: 500
    });
});

$( window ).resize(function () {
    $.sidr('close', 'sidr');
}); */

/* var myMenu = new MyMenu();
myMenu.initLeftMenu(); */
MyMenu.initLeftMenu();